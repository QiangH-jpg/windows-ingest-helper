@echo off
start.bat
